package com.example.orefinder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ServiceCompat
import kotlin.math.abs

class OverlayService : Service() {
    private data class Ore(val name: String, val best: Int, val range: String)

    private val ores = listOf(
        Ore("เพชร", -59, "-64 ถึง 16"),
        Ore("Ancient Debris (Nether)", 15, "8 ถึง 22"),
        Ore("ทอง", -16, "-64 ถึง 32"),
        Ore("เหล็ก", 16, "-64 ถึง 72"),
        Ore("Redstone", -59, "-64 ถึง 16"),
        Ore("Lapis", 0, "-64 ถึง 64"),
        Ore("มรกต", 232, "-16 ถึง 320"),
        Ore("ทองแดง", 48, "-16 ถึง 112")
    )

    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var logView: TextView
    private var open = false
    private var oreIdx = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val prefs get() = getSharedPreferences("ore", Context.MODE_PRIVATE)
    private fun logs(): MutableList<String> =
        prefs.getString("log", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ore", "Ore overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ore")
            .setContentTitle("Ore Overlay กำลังทำงาน")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        ServiceCompat.startForeground(this, 1, n,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8); y = dp(120)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        buildViews()
        wm.addView(root, lp)
    }

    private fun buildViews() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val bubble = TextView(this).apply {
            text = "💎"; textSize = 24f; gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xDD1B1D22.toInt()); setStroke(dp(2), 0xFF4FD8E0.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) + abs(dy) > dp(6)) moved = true
                    if (moved) { lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(root, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggle(); true }
                else -> false
            }
        }
        root.addView(bubble)

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply { setColor(0xEE1B1D22.toInt()); cornerRadius = dp(8).toFloat() }
            layoutParams = LinearLayout.LayoutParams(dp(280), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        panel.addView(label("ความสูง Y ที่เจอมากที่สุด", 0xFF4FD8E0.toInt()))
        panel.addView(label(ores.joinToString("\n") { "${it.name}: Y ${it.best}  (${it.range})" }, Color.WHITE, 12f))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val fx = field("X"); val fy = field("Y"); val fz = field("Z")
        listOf(fx, fy, fz).forEach { row.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        panel.addView(row)

        val oreBtn = btn(ores[0].name) {}
        oreBtn.setOnClickListener { oreIdx = (oreIdx + 1) % ores.size; oreBtn.text = ores[oreIdx].name }
        panel.addView(oreBtn)
        panel.addView(btn("บันทึกพิกัด") {
            val x = fx.text.toString(); val y = fy.text.toString(); val z = fz.text.toString()
            if (x.toIntOrNull() != null && y.toIntOrNull() != null && z.toIntOrNull() != null) {
                val l = logs(); l.add("${ores[oreIdx].name}|$x|$y|$z")
                prefs.edit().putString("log", l.joinToString("\n")).apply()
                fx.setText(""); fy.setText(""); fz.setText("")
                refreshLog()
            }
        })
        logView = label("", Color.WHITE, 13f)
        panel.addView(logView)
        panel.addView(btn("ลบรายการล่าสุด") {
            val l = logs(); if (l.isNotEmpty()) l.removeAt(l.size - 1)
            prefs.edit().putString("log", l.joinToString("\n")).apply()
            refreshLog()
        })
        root.addView(panel)
        refreshLog()
    }

    private fun refreshLog() {
        val l = logs().takeLast(8).reversed()
        logView.text = if (l.isEmpty()) "ยังไม่มีพิกัด" else l.joinToString("\n") {
            val p = it.split("|")
            "${p[0]}  ${p[1]}, ${p[2]}, ${p[3]}"
        }
    }

    private fun toggle() {
        open = !open
        panel.visibility = if (open) View.VISIBLE else View.GONE
        lp.flags = if (open) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        wm.updateViewLayout(root, lp)
    }

    private fun label(t: String, c: Int, size: Float = 14f) = TextView(this).apply {
        text = t; setTextColor(c); textSize = size; setPadding(0, dp(4), 0, dp(4))
    }

    private fun field(h: String) = EditText(this).apply {
        hint = h; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
        textSize = 14f; maxLines = 1
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setOnClickListener { f() }
    }

    override fun onDestroy() {
        if (::root.isInitialized) wm.removeView(root)
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
