package com.example.orefinder

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        col.addView(TextView(this).apply {
            text = "กดเปิดปุ่มลอย แล้วสลับไปเล่น Minecraft\nปุ่ม 💎 จะลอยทับเกม แตะเพื่อเปิดแผงพิกัด"
            textSize = 16f
            gravity = Gravity.CENTER
        })
        col.addView(Button(this).apply {
            text = "เปิดปุ่มลอย"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    ContextCompat.startForegroundService(this@MainActivity,
                        Intent(this@MainActivity, OverlayService::class.java))
                }
            }
        })
        col.addView(Button(this).apply {
            text = "ปิดปุ่มลอย"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        setContentView(col)
    }
}
